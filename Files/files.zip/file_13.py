# Program to write a Dictionary to a Binary File and read it

import pickle
fn = 'binary02.dat'
fh = open(fn, 'wb')
dict1 = dict()
while True:
    print('Enter the Roll No : ', end='')
    rollno = int(input())
    print('Enter the Name    : ', end='')
    sname = input().title()
    print('Enter the Stream  : ', end='')
    stream = input().upper()

    dict1[rollno] = (sname, stream)

    print('Do you want to add new data (Y/N) : ', end='')
    ans = input()
    if ans.upper() == 'N':
        break

pickle.dump(dict1, fh)
fh.close()

fh = open(fn, 'rb')
print("File Content :")
dict1 = pickle.load(fh)
print('   Roll No  | Name              | Stream ')
for k, v in dict1.items():
    print('{0: >10}'.format(k), ' | ', '{0: <15}'.format(v[0]), ' | ', '{0: <15}'.format(v[1]))

fh.close()

