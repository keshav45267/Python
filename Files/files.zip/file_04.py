# Read a file Using .readline() function.
# Readline function returns a String
# to read entire file use for loop
try:
    fh = open(input("Enter the File Name to open "))

except:
    print("Requested File does not exist. ")
    quit()

l = 1
for line in fh:
    print('LINE ', l, ' : ', line.rstrip())
    l += 1


fh.close()