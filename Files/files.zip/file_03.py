# Read a file Using .readline() function.                    
# Readline function returns a String
# every time readline() is called it would read 1 line
# and place the control on the next line
try:
    fh = open(input("Enter the File Name to open "))

except:
    print("Requested File does not exist. ")
    quit()


line1 = fh.readline()
print('LINE 1: ', line1)
print('LINE 1: ', line1, end='')
line2 = fh.readline()
# x = '      rty'  lstrip
# y = 'adfs      ' rstrip
# z = '         fgfgj         ' strip
print('LINE 2: ', line2.rstrip())
line3 = fh.readline()
print('LINE 3: ', line3.rstrip())
line4 = fh.readline()
print('LINE 4: ', line4.rstrip())

fh.close()