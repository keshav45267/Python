# 4. Program to print the frequencies of each number in the given list

n = int(input("Enter How Many Numbers in the list : "))
original_List =[]
unique_list = []
for i in range(n):
    original_List.append(eval(input("Enter the Number ")))
print("Original List: ",original_List)
for num in original_List:
    if num not in unique_list:
        unique_list.append(num)

print("Frequency of Numbers : ")
for num in unique_list:
    print(num,original_List.count(num))