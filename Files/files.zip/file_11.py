# Program to write a line to a Binary File and read it
# Binary files are in machine readable form

import pickle
fn = input("Enter the File Name to open ")
fh = open(fn, 'wb')

n = int(input("Enter how many items in the list? "))
items = list()
for i in range(n):
    print("Enter the item", i+1, " of the list : ", end='')
    items.append(input())


pickle.dump(items, fh)
fh.close()

fh = open(fn, 'rb')
print("File Content :")
list1 = pickle.load(fh)
for lines in list1:
    print(lines)

fh.close()

