# readlines() reads the entire content in the file
# loop through the lines to print the content
# consumes a lot of memory according to the file size

try:
    fh = open(input("Enter the File Name to open "))

except:
    print("Requested File does not exist. ")
    quit()


lines = fh.readlines()
print(type(lines),lines)
l = 1
for line in lines:
    print('LINE ', l, ' : ', line, end='')
    l += 1

