# 7. Write a program to print the prime number available in the given list
def prime_check(n):
    for i in range(2,int(n**0.5)):
        if n%i == 0:
            break
    else:
        print(n, end=" ")

n = int(input("How Nmay Numbers in the lsit : "))
num_list = []
for i in range(n):
    num_list.append(int(input("Enter the Number : ")))
print("Prime Numbers in the List are : ", end="")
for i in num_list:
    if(i>1):
        prime_check(i)