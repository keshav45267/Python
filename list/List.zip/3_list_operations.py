# 3. Write a program to input a list and perform all the operations on the list
# like min, max, sort etc.
mylist = list()


def add_item():
    global mylist
    l = len(mylist)
    item = int(input("Enter the item for index no "+ str(l) + " : "))
    mylist.append(item)
    print(' Item added in the list. New List : ', mylist)


def remove_item():
    global mylist
    if len(mylist) == 0:
        print('List is empty ')
    else:
        x = int(input('Enter the value of item to be deleted from the list '))
        if x in mylist:
            loc = mylist.index(x)
            del mylist[loc]
            print(' Item removed from the list. New List : ', mylist)
        else:
            print('Specified item is not in the list ')


def update_item():
    global mylist
    if len(mylist) == 0:
        print('List is empty ')
    else:
        x = int(input('Enter the index number of item to be updated in the list '))
        if (x >= 0) and (x < len(mylist)):
            val = int(input('Enter the New value '))
            mylist[x] = val
            print(' Item updated in the list. New List : ', mylist)
        else:
            print('Specified index is out of range ')


while 1:
    print('Select the operation to be performed : ')
    print('1: Add item in list ')
    print('2: Remove item from the list ')
    print('3: update item in list ')
    print('4: Show items in list ')
    print('5: Exit Program ')
    c = int(input('Choice : '))

    if c < 1 or c > 5:
        print('Invalid choice ')
    elif c == 1:
        add_item()
    elif c == 2:
        remove_item()
    elif c == 3:
        update_item()
    elif c == 4:
        print(mylist)
    else:
        print('Program Terminated. ')
        break

