# 5. Write a program to print the frequencies of vowels in the given string
text = input("Enter the String : ")
text_list = list(text.upper())
ul=list()
print('Frequency of items: ')

for i in text_list:
    if ((i in 'AEIOU') and (i not in ul)):
        ul.append(i)
        print(i, text_list.count(i))
