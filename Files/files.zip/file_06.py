# Program to write a line to a file and read it
fn = input("Enter the File Name to open ")
fh = open(fn, 'w')

text = input("Type the text to be written in the file : ")
fh.write(text)
fh.close()

fh = open(fn, 'r')
print("File Content :")
print(fh.read())
fh.close()

