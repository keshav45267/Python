# read() reads the entire content of the file
# consumes a lot of memory according to the file size

try:
    fh = open(input("Enter the File Name to open "))

except:
    print("Requested File does not exist. ")
    quit()


lines = fh.read()
print(lines)
fh.close()
