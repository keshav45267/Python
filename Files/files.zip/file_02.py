# read(n) reads the first n characters from the file
# loop through the file to print the content
# seek() moves the file handler/ cursor to the mentioned location

try:
    fh = open(input("Enter the File Name to open "))

except:
    print("Requested File does not exist. ")
    quit()

while 1:
    txt = fh.read(15)
    if txt :
        print(txt)
    else:
        break

fh.close()

