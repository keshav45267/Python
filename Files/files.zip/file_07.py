# Program to write a line to a file and read it
# write function takes string as input to write it to file
# to write data in different lines we need to provide \n
fn = input("Enter the File Name to open ")
fh = open(fn, 'w')

print("Type or Paste the text and press Ctrl+Z ")
contents = []
while True:
    try:
        line = input()
    except EOFError:
        break
    contents.append(line)

for line in contents:
    fh.write(line+'\n')

fh.close()

fh = open(fn, 'r')
print("File Content :")
print(fh.read())
fh.close()

