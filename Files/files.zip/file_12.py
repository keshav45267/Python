# Program to write a Dictionary to a Binary File and read it

import pickle
fn = 'binary02.dat'
fh = open(fn, 'wb')

dict1 = {'Name': 'Ajay', 'Roll no': 2356, 'Stream': 'CSE'}
pickle.dump(dict1, fh)
fh.close()

fh = open(fn, 'rb')
print("File Content :")
dict1 = pickle.load(fh)
for k, v in dict1.items():
    print(k, ': ', v)

fh.close()

