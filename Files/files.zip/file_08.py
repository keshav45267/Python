# Program to write a line to a file and read it
# to write sequence like List, Tuple etc. wlritlines() is used

fn = input("Enter the File Name to open ")
fh = open(fn, 'w')

n = int(input("Enter how many items in the list? "))
items = list()
for i in range(n):
    print("Enter the item", i+1, " of the list : ", end='')
    items.append(input()+'\n')

print(items)
fh.writelines(items)
fh.close()

fh = open(fn, 'r')
print("File Content :")
print(fh.read())
fh.close()

