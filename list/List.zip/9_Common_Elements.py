# 9. Write a program to find common elements between two lists.
m = int(input("How Nmay Elements in the lsit 1 : "))
num_list1 = []
for i in range(m):
    num_list1.append(input("Enter the Element : "))

n = int(input("How Nmay Elements in the lsit 2 : "))
num_list2 = []
for i in range(n):
    num_list2.append(input("Enter the Element : "))

print("Common Elements in the Lists are : ", end="")
if m>n:
    for i in num_list2:
        if (i in num_list1):
            print(i, end=" ")
else:
    for i in num_list1:
        if (i in num_list2):
            print(i, end=" ")

# Anothe way
# if m > n:
#     min = n
#     min_list = num_list2
#     max_list = num_list1
# else:
#     min = m
#     min_list = num_list1
#     max_list = num_list2

# print("Common Elements in the Lists are : ", end="")
# for i in min_list:
#     if (i in max_list):
#         print(i, end=" ")