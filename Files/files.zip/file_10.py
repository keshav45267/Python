# write to a file Using with statement.
# with statement closes the file automatically 
# when with statement is complete

fn = input("Enter the File Name to open ")

with open(fn, 'w') as fh:
    l = int(input('How many lines to input : '))
    for i in range(l):
        print('Type Line ', i+1, ' : ', end='')
        fh.write(input()+'\n')

fh = open(fn, 'r')

print(fh.read())
fh.close()
