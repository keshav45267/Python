# 6. Write a program to print the frequencies of even number and odd number and their respective sum
n = int(input("How Nmay Numbers in the lsit : "))
num_list = []
e_count = 0
o_count = 0
e_sum = 0
o_sum = 0
for i in range(n):
    num = int(input("Enter the Number : "))
    num_list.append(num)
    if (num % 2 == 0 ):
        e_count += 1
        e_sum += num
    else:
        o_count += 1
        o_sum += num
print("Even Numbers in the List are : ",e_count, " nd Sum of Even Number is ", e_sum)
print("Odd Numbers in the List are : ",o_count, " nd Sum of Odd Number is ", o_sum)
