# Program to append a line to a file and read it
# to append a line write() function is used

fn = input("Enter the File Name to Append the data ")
fh = open(fn, 'a')

n = int(input("Enter how many Students data is available? "))

for i in range(n):
    fh.write('Roll No   : ' + input("Enter the Roll No : ") + '\n')
    fh.write('Name      : ' + input("Enter the Name : ")+'\n')
    fh.write('Department: ' + input("Enter the Department : ")+'\n')

fh.close()

fh = open(fn, 'r')
print("File Content :")
print(fh.read())
fh.close()

